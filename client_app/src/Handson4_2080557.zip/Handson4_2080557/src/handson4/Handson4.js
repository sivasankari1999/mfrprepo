import React from "react";
import './Handson4.css'

class Handson4 extends React.Component {
    constructor() {
        super();
        this.state = {
 /*-----------------------------------Form Field states-------------------------------------------------*/          
            asso_name: '',
            asso_id: '',
            pid: '',
            locationType: '',
            Onshore: ["US", "Non-US"],
            Offshore: ["Chennai", "Bangalore", "Kochi", "Pune", "Hyderabad"],
            location: '',
            comments: '',
            profileImg: '',
            skills: ["HTML5,CSS3,JS", "Angular 8", "Express JS",
                "SASS", "React JS", "Node JS",
                "ES5,ES6,ES7", "Veu JS", "Mongo DB",
                "Bootstrap 4", "TypeScript"],
            selectedSkills: [],

/*------------------------------------Error Messages----------------------------------------------------*/
            asso_name_err_mess: '',
            asso_id_err_mess: '',
            pid_err_mess: '',
            skill_err_mess: '',
            location_err_mess: '',
            profile_err_mess: '',
            comments_err_mess: '',

/*---------------------------------------Flag values-------------------------------------------------*/
            asso_name_flag: false,
            asso_id_flag: false,
            pid_flag: false,
            skill_flag: false,
            location_flag: false,
            profile_flag: false,
            comments_flag: false,

            formStatus:false,
        }
    }
    changeHandler = (event) => {
        //console.log(event.target.value);
        this.setState({ [event.target.name]: event.target.value })
    }
    skillChangeHandler = (e) => {
        console.log("Name: ", e.target.name);
        console.log("Value: ", e.target.value);
        console.log("Checked: ", e.target.checked);
        let { selectedSkills } = this.state;
        if (e.target.checked) {
            selectedSkills.push(e.target.value)
        } else {
            let ind = selectedSkills.indexOf(e.target.value);
            selectedSkills.splice(ind, 1);
        }
        this.setState({ selectedSkills })
    }
    profileChangeHandler = (event) => {
        // console.log(event.target.files);
        if (event.target.files.length == 0) {
            console.log("No file is Selected");
            return;
        }
        let profileImg = event.target.files[0];
        console.log("File: ", profileImg);
        console.log("FileName", profileImg.name);
        console.log("File Size: ", profileImg.size);
        console.log("File Type: ", profileImg.type);
        this.setState({ profileImg });

    }
    submitForm = (event) => {
        event.preventDefault();
        console.log(this.state);       
    }
    Validations = (e) => {
        let {
            asso_name_flag,
            asso_id_flag,
            pid_flag,
            skill_flag,
            location_flag,
            profile_flag,
            comments_flag,
            formStatus} = this.state;
        console.log("from Validations");
        console.log(e.target.name);
/*----------------------------------------Associate name validation-----------------------------------------*/
        if (e.target.name === "asso_name") {
            let { asso_name, asso_name_err_mess } = this.state;
            if (asso_name == undefined || asso_name.length == 0) {
                asso_name_err_mess = "Please Enter the Associate Name."
            }
            else {
                console.log("Associate Name: ", asso_name);
                console.log("Name Length: ", asso_name.length);
                let nameReg = /^([a-zA-Z ]{5,30})$/
                if (!nameReg.test(asso_name)) {
                    asso_name_err_mess = "Accepts Alphabets,space & Min 5 to Max 30 char"
                }
                else {
                    asso_name_err_mess = ""
                }
                console.log(nameReg.test(asso_name));
            }
            if (asso_name_err_mess) {
                e.target.classList.add("field-error")
                asso_name_flag=false

            } else {
                e.target.classList.remove("field-error")
                asso_name_flag =true
            }
            this.setState({ asso_name_err_mess,asso_name_flag })
        }
/*---------------------------------------Associate Id validation-------------------------------------------*/
        if (e.target.name === "asso_id") {
            let { asso_id, asso_id_err_mess} = this.state;
            if (asso_id.length == 0) {
                asso_id_err_mess = "Please Enter the Associate ID"
            }
            else {
                let idReg = /^([0-9]{6,6})$/
                if (!idReg.test(asso_id)) {
                    asso_id_err_mess = "Invalid Associate ID"
                }
                else {
                    asso_id_err_mess = ""
                }
                console.log(idReg.test(asso_id));
            }
            if (asso_id_err_mess) {
                e.target.classList.add("field-error")
                asso_id_flag=false
            } else {
                e.target.classList.remove("field-error")
                asso_id_flag = true
            }
            this.setState({ asso_id_err_mess,asso_id_flag })
        }
/*---------------------------------------Project ID validation-------------------------------------------*/
        if (e.target.name === "pid") {
            let { pid, pid_err_mess } = this.state;
            if (pid == undefined || pid.length == 0) {
                pid_err_mess = "Please Enter the Project ID"
            }
            else {
                let pidReg = /^([a-zA-Z0-9]{12,12})$/
                if (!pidReg.test(pid)) {
                    pid_err_mess = "Invalid Project ID"
                }
                else {
                    pid_err_mess = ""
                }
                console.log(pidReg.test(pid));
            }
            if (pid_err_mess) {
                e.target.classList.add("field-error")
                pid_flag=false
            } else {
                e.target.classList.remove("field-error")
                pid_flag = true
            }
            this.setState({ pid_err_mess,pid_flag })
        }
/*--------------------------------------------Location Validation---------------------------------------*/
        if (e.target.name == "location") {
            let { location, location_err_mess, Onshore, Offshore, locationType } = this.state;
            console.log(location);
            if (location == "" || location == "Select Location") {
                location_err_mess = "Please Select the Location"
                this.setState({ locationType })
                location_flag=false
            }
            if (Onshore.includes(location) || Offshore.includes(location)) {
                location_err_mess = ""
                this.setState({ locationType })
                location_flag = true
            }
            this.setState({ location, location_err_mess,location_flag });
        }
/*------------------------------------------Skills Validations--------------------------------------*/
        if (e.target.name == "Skill") {
            let { selectedSkills, skill_err_mess } = this.state;
            if (selectedSkills.length < 5) {
                skill_err_mess = "Please Select Min 5 Skills."
                skill_flag=false
            }
            else {
                skill_err_mess = ""
                skill_flag = true
            }
            this.setState({ skill_err_mess, skill_flag})
        }
/*----------------------------------------profile img validation----------------------------------*/
        let { profile_err_mess } = this.state;
        if (e.target.name == "profileImg") {
            let profileImg = e.target.files;
            if (profileImg == undefined || profileImg.length == 0) {
                profile_err_mess = "Please upload the profile picture"
            }
            else {
                profile_err_mess = ""
            }
            if (profile_err_mess) {
                e.target.classList.add("field-error")
                profile_flag=false
            } else {
                e.target.classList.remove("field-error")
                profile_flag = true
            }
            this.setState({ profile_err_mess,profile_flag })
        }
/*------------------------------------------comments validation---------------------------------------------*/
        let { comments, comments_err_mess } = this.state;
        if (e.target.name == "comments") {
            if (comments.length == 0) {
                comments_err_mess = "Please enter the comments"
            }
            else {
                comments_err_mess = ""
            }
            if (comments_err_mess) {
                e.target.classList.add("field-error")
                comments_flag=false
            } else {
                e.target.classList.remove("field-error")
                comments_flag = true
            }
            this.setState({ comments_err_mess,comments_flag });
        }
/*------------------------------------Submit button disabling------------------------------------------*/
        if(asso_id_flag && asso_name_flag && pid_flag && location_flag && 
            skill_flag && profile_flag && comments_flag ){
                formStatus=true
            }
            else{
                formStatus=false
            }
            this.setState({formStatus});
    }
    resetForm = () => {
        let { asso_name, asso_id, pid, location,
            comments, locationType, selectedSkills } = this.state;
        let { asso_name_err_mess, asso_id_err_mess, pid_err_mess,
            skill_err_mess, location_err_mess, profile_err_mess, comments_err_mess } = this.state
/*-----------------------------------------form fields------------------------------------*/
        asso_name = '';
        asso_id = '';
        pid = '';
        locationType = '';
        location = '';
        comments = '';
        locationType = '';
        selectedSkills = [];
/*----------------------------------------error fields------------------------------------------*/
        asso_name_err_mess = '';
        asso_id_err_mess = '';
        pid_err_mess = '';
        skill_err_mess = '';
        location_err_mess = '';

        this.setState({
            asso_name, asso_id, pid, location,
            comments, locationType, selectedSkills
        }, () => console.log(this.state))
        this.setState({
            asso_name_err_mess, asso_id_err_mess, pid_err_mess,
            skill_err_mess, location_err_mess
        })

/*---------------------------------------field error---------------------------------------------*/
        let fielderror = document.getElementsByClassName('field-error');
        fielderror = [...fielderror];
        fielderror.forEach((ele) => {
            ele.classList.remove('field-error');
        })
        console.log(fielderror);
    }
    canBeSubmitted() {
        const {asso_name_err_mess, asso_id_err_mess, pid_err_mess,
            skill_err_mess, location_err_mess, profile_err_mess, comments_err_mess }  = this.state;
        return asso_name_err_mess==""&& asso_id_err_mess==""&& pid_err_mess==""&&
        skill_err_mess=="" && location_err_mess=="" && profile_err_mess=="" && comments_err_mess==""
      }
    
    render() {
        const isEnabled = this.canBeSubmitted();
        //field properties
        let { asso_name, asso_id, pid, location,
            comments, locationType, selectedSkills } = this.state;
        //Error properties    
        let { asso_name_err_mess, asso_id_err_mess, pid_err_mess,
            skill_err_mess, location_err_mess, profile_err_mess, comments_err_mess } = this.state
        return (
            <div className="container">
                <h3>Form Validation</h3>
                <form onSubmit={this.submitForm}>
{/*-----------------------------------------Asso_name field---------------------------------------------*/}             
                    <div className="py-3">
                        <input type="text" className="form-control"
                            name="asso_name" placeholder="Associate Name"
                            value={asso_name}
                            onChange={this.changeHandler}
                            onBlur={this.Validations}></input>
                        {asso_name_err_mess &&
                            <p className="text-danger">{asso_name_err_mess}</p>
                        }
                    </div>
{/*--------------------------------------------Asso_id field--------------------------------------------*/}                    
                    <div className="py-2">
                        <input type="number" className="form-control"
                            name="asso_id" placeholder="Associate ID"
                            value={asso_id}
                            onChange={this.changeHandler}
                            onBlur={this.Validations}></input>
                        {asso_id_err_mess &&
                            <p className="text-danger">{asso_id_err_mess}</p>
                        }
                    </div>
{/*------------------------------------------Project id field-----------------------------------------*/}                    
                    <div className="py-2">
                        <input type="text" className="form-control"
                            name="pid" placeholder="Project ID"
                            value={pid} onChange={this.changeHandler}
                            onBlur={this.Validations}></input>
                        {
                            pid_err_mess &&
                            < p className="text-danger">{pid_err_mess}</p>
                        }
                    </div>
{/*----------------------------------------Location type-----------------------------------------------*/}
                    <div className="py-2 form-check-inline" >
                        <input type="radio" name="locationType"
                            value="Onshore" onChange={this.changeHandler}
                            onBlur={this.Validations}
                            className="form-check-input"></input>
                        <label className="mx-2">Onshore</label>
                    </div>
                    <div className="py-2 form-check-inline" >
                        <input type="radio" name="locationType"
                            value="Offshore" onChange={this.changeHandler}
                            onBlur={this.Validations}
                            className="form-check-input"></input>
                        <label className="mx-2">Offshore</label>
                    </div>
{/*-----------------------------------------Location-------------------------------------------------*/}                    
                    <div className="py-2">
                        <select className="form-select" name="location"
                            value={location} onChange={this.changeHandler}
                            onBlur={this.Validations}>
                            <option >Select Location</option>
                            {
                                this.state.locationType === "Onshore" &&
                                this.state.Onshore.map((location, ind) => {
                                    return <option value={location} key={ind}>{location}</option>
                                })
                            }
                            {
                                this.state.locationType === "Offshore" &&
                                this.state.Offshore.map((location, ind) => {
                                    return <option value={location} key={ind}>{location}</option>
                                })
                            }
                        </select>
                        {
                            location_err_mess &&
                            <p className="text-danger">{location_err_mess}</p>
                        }
                    </div>
{/*-------------------------------------------Skills Checkbox----------------------------------------*/}                    
                    <div onBlur={this.Validations} name="skills-container" className="row">
                        {
                            this.state.skills.map((skill, ind) => {
                                return <div className="col-md-4 float-start text-start" key={ind}>
                                    <input type="checkbox" name="Skill"
                                        value={skill}
                                        onChange={this.skillChangeHandler}
                                        className="form-check-input"
                                    ></input>
                                    <label className="mx-3">{skill}</label>
                                </div>
                            })
                        }
                        {
                            skill_err_mess &&
                            <p className="text-danger">{skill_err_mess}</p>
                        }
                    </div>
                    <div className="clearfix"></div>
{/*------------------------------------------Profile Picture------------------------------------------*/}
                    <div className="py-2 text-start">
                        <label>Upload Profile</label>
                        <input type="file" className="form-control"
                            onChange={this.profileChangeHandler}
                            onBlur={this.Validations}
                            name="profileImg"></input>
                        {
                            profile_err_mess &&
                            <p className="text-danger">{profile_err_mess}</p>
                        }
                    </div>
{/*---------------------------------------------Comments-------------------------------------------------*/}
                    <div className="py-2">
                        <textarea className="form-control" placeholder="Comments"
                            rows="4" name="comments"
                            value={comments} onChange={this.changeHandler}
                            onBlur={this.Validations}></textarea>
                        {
                            comments_err_mess &&
                            <p className="text-danger">{comments_err_mess}</p>
                        }
                    </div>

                    <div className="py-2">
                        <div className="row">
                            <div className="col-auto">
                                <button disabled={!this.state.formStatus} className="btn btn-primary"
                                >Submit</button>
                            </div>
                            <div className="col-auto">
                                <button className="btn btn-danger"
                                    type="reset"
                                    onClick={this.resetForm}>Reset</button>
                            </div>
                        </div>
                    </div>

                </form>
            </div>
        )
    }
}
export default Handson4;