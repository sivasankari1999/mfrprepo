import React from "react"; 
import "../layout/Header.css";
export default function Header(){
    return(
        <div>
            <div className="header">
            <h1>Curry Kitchen</h1>
            </div>
            <div className="main-image">
                <img src={require("../../assets/page1food.jpg")}></img>
                <div className="centred">Join us to feed your hunger.<br/>
                Order now and get tasty <br/>restaurant like food at your home.</div>
                <button className="btn1">Get Started</button>     
            </div>
        </div>
    )
}